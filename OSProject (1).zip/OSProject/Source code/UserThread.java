package net.codejava.networking.chat.server;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

/**
 * This thread handles connection for each connected client, so the server
 * can handle multiple clients at the same time.
 *
 * @author www.codejava.net
 */
class AES {
    private static final String ALGORITHM = "AES";
    private static final String KEY = "mysecretkey12345"; // 128 bit key

    public static String encrypt(String message) throws Exception {
        SecretKeySpec secretKey = new SecretKeySpec(KEY.getBytes(), ALGORITHM);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);

        byte[] encryptedBytes = cipher.doFinal(message.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    public static String decrypt(String encryptedMessage) throws Exception {
        SecretKeySpec secretKey = new SecretKeySpec(KEY.getBytes(), ALGORITHM);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);

        byte[] encryptedBytes = Base64.getDecoder().decode(encryptedMessage);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        return new String(decryptedBytes);
    }
}

public class UserThread extends Thread {
    private Socket socket;
    private ChatServer server;
    private BufferedWriter writer;
    private BufferedReader reader;

    public UserThread(Socket socket, ChatServer server) {
        this.socket = socket;
        this.server = server;
    }

    public void run() {
        try {
            InputStream input = socket.getInputStream();
            reader = new BufferedReader(new InputStreamReader(input));

            OutputStream output = socket.getOutputStream();
            writer = new BufferedWriter(new OutputStreamWriter(output));

            printUsers();

            String userName = reader.readLine();
            server.addUserName(userName);

            String serverMessage = "New user connected: " + userName;
            server.broadcast(serverMessage, this);

            String clientMessage = "";
            AES obj = new AES();
            do {
                try {
                    clientMessage = reader.readLine();
                    clientMessage = obj.decrypt(clientMessage);
                    serverMessage = "[" + userName + "]: " + clientMessage;
                    server.broadcast(serverMessage, this);
                } catch (Exception e) {
                    System.out.println(e);
                }
            } while (!clientMessage.equals("bye"));

            server.removeUser(userName, this);
            socket.close();

            serverMessage = userName + " has quitted.";
            server.broadcast(serverMessage, this);

        } catch (IOException ex) {
            System.out.println("Error in UserThread: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * Sends a list of online users to the newly connected user.
     */
    void printUsers() {
        if (server.hasUsers()) {
            try {
                writer.write("Connected users: " + server.getUserNames() + "\n");
                writer.flush();
            } catch (IOException e) {
                System.out.println("Error printing users: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            try {
                writer.write("No other users connected\n");
                writer.flush();
            } catch (IOException e) {
                System.out.println("Error printing users: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    /**
     * Sends a message to the client.
     */
    void sendMessage(String message) {
        try {
            writer.write(message + "\n");
            writer.flush();
        } catch (IOException e) {
            System.out.println("Error sending message: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
